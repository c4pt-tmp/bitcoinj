# Contributing Guidelines

We love pull requests from everyone! Bug reports are also welcome.

However if you've got a question or would like to start a discussion, please post to the
[bitcoinj google group](https://groups.google.com/forum/#!forum/bitcoinj) or the
[Bitcoin stack exchange](https://bitcoin.stackexchange.com/questions/tagged/bitcoinj).
